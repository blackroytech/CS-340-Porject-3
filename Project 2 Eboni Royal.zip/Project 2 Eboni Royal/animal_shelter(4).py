from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, user, passwd, host, port, database, collection): #updated for dashboard
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        USER = 'aacuser'
        PASS = 'cookie24'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 31609
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]
        print("Successful connection")
       
  # Complete this create method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert_one(data) # data should be dictionary 
            return True #return true if insert is successful
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            return False
   # Complete a read method to implement the R in CRUD
    def read(self, data):
        if data is not None:
            cursor = self.database.animals.find(data)
            return list(cursor) #convert cursor to a list
        
        else:
            self.database.animals.find({})
            return [] #print empty list
        
   # Complete an Update method to implement the U in CRUD
    def update(self, data, new_data): #add another arg
        if data is not None:
            updatedResults = self.database.animals.update_many(data, {"$set": new_data}) #update documents with update_one
            return updatedResults.modified_count #return how many documents have been updated
        else:
            raise Exception("Error updating document")
            return 0
    # Complete a Delete method to implement the D in CRUD
    def delete(self, data):
        if data is not None:
            deletedResults = self.database.animals.delete_many(data) #delete all matching searches
            return deletedResults.deleted_count #return how many documents have been deleted
        else:
            raise Exception("Error updating document")
            return 0 
        
        
            
            
                
            

        